# Changelog

## [2.1.0]
- Upgraded all dependencies

## [2.0.0]

### Changed
- Upgrade to Bootstrap 5

## [1.1.0]

### Changed
- Upgrade to webpack 5

## [1.0.0]

### Added
- Intial release
